# Sebedisana QV — Android app

A native Android quantity converter written in Kotlin. It uses Android platform widgets and has no third-party runtime dependencies.

## Features
- Dark interface
- Length, weight/mass, volume, temperature, area, speed, time and digital data conversions
- Live conversion while typing
- Swap and clear controls
- Saved favourites and recent conversion history (stored locally on the device)

## Open in Android Studio
1. Extract the project ZIP.
2. Open the `SebedisanaQV` folder in Android Studio.
3. Allow Gradle to sync. Use JDK 17 and Gradle 8.7 if prompted.
4. Select an emulator or connect an Android phone with USB debugging enabled.
5. Press Run.

## Build a shareable APK
See [BUILD_APK_GUIDE.md](BUILD_APK_GUIDE.md). A GitHub Actions workflow is included at `.github/workflows/build-apk.yml`; it builds an installable debug APK and makes it available as a workflow artifact.

## Build settings
- Android Gradle Plugin: 8.5.2
- Kotlin Android plugin: 1.9.24
- Gradle: 8.7
- JDK: 17
- Compile/target SDK: 35
- Minimum Android version: Android 6.0 (API 23)
- Package: `co.za.sebedisana.qv`

## Notes
- Temperature conversions use Celsius/Fahrenheit/Kelvin formulas.
- US customary volume units and Imperial gallon are listed separately.
- Digital storage includes decimal KB/MB/GB and binary KiB/MiB/GiB.
