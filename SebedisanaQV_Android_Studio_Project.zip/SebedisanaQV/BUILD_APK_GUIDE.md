# Build a shareable Sebedisana QV APK

This repository includes a GitHub Actions workflow that builds an installable **debug APK**. The APK is suitable for sharing with testers, friends and family. It is not the signed release artifact for Google Play.

## Create the APK using GitHub Actions

1. Sign in to GitHub and create a new repository (for example, `SebedisanaQV`).
2. Upload the contents of this project folder to the repository, keeping the `.github/workflows/build-apk.yml` file and its folder structure.
3. Open the repository's **Actions** tab.
4. Select **Build Sebedisana QV APK** and press **Run workflow** (or push to the `main` branch to trigger a build).
5. Wait for the workflow to finish successfully.
6. Open the completed workflow run. Under **Artifacts**, download `Sebedisana-QV-APK` and extract it.
7. Share `app-debug.apk` through WhatsApp, Google Drive, or another file-sharing service.

## Install on Android

The recipient downloads the APK, opens it, and allows their browser or file manager to install unknown apps if Android asks. They should only install APKs received from a source they trust.

## Important

- The build uses JDK 17, Gradle 8.7, Android Gradle Plugin 8.5.2 and Android SDK 35, matching the current project configuration.
- This is a debug-signed APK for direct testing/sharing, not a Play Store release. Google Play requires a properly signed Android App Bundle (AAB) and current target API compliance.
- The APK is not generated until the GitHub Actions workflow runs successfully. This project archive itself is source code, not an APK.
