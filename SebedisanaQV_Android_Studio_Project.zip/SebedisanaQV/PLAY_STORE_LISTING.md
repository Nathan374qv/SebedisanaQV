# Google Play listing — Sebedisana QV

**App name:** Sebedisana QV – Quantity Converter  
**Suggested short description:** Convert length, weight, volume, temperature, area, speed, time and data units.

## Full description
Sebedisana QV makes everyday unit conversions quick and simple. Choose a measurement category, enter a value and see the converted result instantly.

**Conversions included**
- Length: mm, cm, metres, kilometres, inches, feet, yards and miles
- Weight and mass: mg, g, kg, tonnes, ounces, pounds and stone
- Volume: millilitres, litres, cubic metres, US customary measures and Imperial gallons
- Temperature: Celsius, Fahrenheit and Kelvin
- Area: metric units, hectares, acres and square feet
- Speed: m/s, km/h, mph and knots
- Time: milliseconds, seconds, minutes, hours, days and weeks
- Digital data: bits, bytes, decimal and binary units

Save favourite conversions and revisit your recent conversion history. Your saved favourites and history are stored locally on your device.

**Category:** Tools  
**Suggested content rating:** Everyone (complete the official questionnaire in Play Console)  
**Ads:** No ads included in this project.  
**Data collection:** The app has no network permission and does not transmit user-entered values. Verify the final merged manifest and SDK behaviour before completing the Play Console Data safety form.

## Required store assets
- App icon: 512 × 512 PNG (provide a final 512px icon in Play Console)
- Feature graphic: 1024 × 500 PNG
- At least 2 phone screenshots; use genuine screenshots from the final app
- Privacy policy URL: host `PRIVACY_POLICY_TEMPLATE.md` as a public webpage and enter its URL in Play Console
