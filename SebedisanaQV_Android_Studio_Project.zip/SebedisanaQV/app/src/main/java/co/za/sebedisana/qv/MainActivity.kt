package co.za.sebedisana.qv

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.content.Context
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*
import android.text.Editable
import android.text.TextWatcher
import org.json.JSONArray
import org.json.JSONObject
import java.text.DecimalFormat
import kotlin.math.*

class MainActivity : Activity() {
    private data class UnitDef(val name: String, val symbol: String, val factor: Double = 1.0, val offset: Double = 0.0)
    private data class Category(val name: String, val units: List<UnitDef>)

    private val bg = Color.rgb(16, 24, 32)
    private val panel = Color.rgb(26, 38, 49)
    private val panel2 = Color.rgb(34, 49, 62)
    private val mint = Color.rgb(85, 214, 190)
    private val white = Color.rgb(239, 245, 247)
    private val muted = Color.rgb(155, 174, 185)
    private val prefs by lazy { getSharedPreferences("sebedisana_qv", Context.MODE_PRIVATE) }
    private val fmt = DecimalFormat("#,##0.########")

    private val categories = listOf(
        Category("Length", listOf(
            UnitDef("Millimetre", "mm", 0.001), UnitDef("Centimetre", "cm", 0.01),
            UnitDef("Metre", "m", 1.0), UnitDef("Kilometre", "km", 1000.0),
            UnitDef("Inch", "in", 0.0254), UnitDef("Foot", "ft", 0.3048),
            UnitDef("Yard", "yd", 0.9144), UnitDef("Mile", "mi", 1609.344)
        )),
        Category("Weight / Mass", listOf(
            UnitDef("Milligram", "mg", 0.000001), UnitDef("Gram", "g", 0.001),
            UnitDef("Kilogram", "kg", 1.0), UnitDef("Metric tonne", "t", 1000.0),
            UnitDef("Ounce", "oz", 0.028349523125), UnitDef("Pound", "lb", 0.45359237),
            UnitDef("Stone", "st", 6.35029318)
        )),
        Category("Volume", listOf(
            UnitDef("Millilitre", "ml", 0.001), UnitDef("Litre", "L", 1.0),
            UnitDef("Cubic metre", "m³", 1000.0), UnitDef("US teaspoon", "tsp", 0.00492892159),
            UnitDef("US tablespoon", "tbsp", 0.0147867648), UnitDef("US cup", "cup", 0.236588237),
            UnitDef("US gallon", "gal", 3.785411784), UnitDef("Imperial gallon", "Imp gal", 4.54609)
        )),
        Category("Temperature", listOf(
            UnitDef("Celsius", "°C"), UnitDef("Fahrenheit", "°F"), UnitDef("Kelvin", "K")
        )),
        Category("Area", listOf(
            UnitDef("Square millimetre", "mm²", 0.000001), UnitDef("Square centimetre", "cm²", 0.0001),
            UnitDef("Square metre", "m²", 1.0), UnitDef("Square kilometre", "km²", 1_000_000.0),
            UnitDef("Hectare", "ha", 10000.0), UnitDef("Acre", "ac", 4046.8564224),
            UnitDef("Square foot", "ft²", 0.09290304)
        )),
        Category("Speed", listOf(
            UnitDef("Metres per second", "m/s", 1.0), UnitDef("Kilometres per hour", "km/h", 1.0 / 3.6),
            UnitDef("Miles per hour", "mph", 0.44704), UnitDef("Knots", "kn", 0.514444444)
        )),
        Category("Time", listOf(
            UnitDef("Millisecond", "ms", 0.001), UnitDef("Second", "s", 1.0),
            UnitDef("Minute", "min", 60.0), UnitDef("Hour", "h", 3600.0),
            UnitDef("Day", "d", 86400.0), UnitDef("Week", "wk", 604800.0)
        )),
        Category("Data", listOf(
            UnitDef("Bit", "bit", 1.0), UnitDef("Byte", "B", 8.0),
            UnitDef("Kilobyte (decimal)", "KB", 8000.0), UnitDef("Megabyte (decimal)", "MB", 8_000_000.0),
            UnitDef("Gigabyte (decimal)", "GB", 8_000_000_000.0),
            UnitDef("Kibibyte", "KiB", 8192.0), UnitDef("Mebibyte", "MiB", 8_388_608.0),
            UnitDef("Gibibyte", "GiB", 8_589_934_592.0)
        ))
    )

    private lateinit var categorySpinner: Spinner
    private lateinit var fromSpinner: Spinner
    private lateinit var toSpinner: Spinner
    private lateinit var input: EditText
    private lateinit var resultText: TextView
    private lateinit var resultUnit: TextView
    private lateinit var historyBox: LinearLayout
    private lateinit var favouritesBox: LinearLayout
    private var selectedCategory = 0
    private var updating = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = bg
        window.navigationBarColor = bg
        buildScreen()
        refreshSavedLists()
        updateResult()
    }

    private fun buildScreen() {
        val scroll = ScrollView(this).apply { setBackgroundColor(bg); isFillViewport = true }
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(18), dp(20), dp(28))
        }
        scroll.addView(root)
        setContentView(scroll)

        val header = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        header.addView(label("SEBEDISANA", 13, mint, true))
        header.addView(label("Quantity Converter", 28, white, true).apply { setPadding(0, dp(3), 0, 0) })
        header.addView(label("Convert everyday measurements in seconds.", 14, muted, false).apply {
            setPadding(0, dp(5), 0, dp(18))
        })
        root.addView(header)

        val converterCard = card()
        root.addView(converterCard, matchWrap())
        converterCard.addView(label("CONVERSION TYPE", 11, muted, true))
        categorySpinner = spinner(categories.map { it.name })
        converterCard.addView(categorySpinner, matchWrap(dp(10)))
        categorySpinner.onItemSelectedListener = simpleListener { position ->
            selectedCategory = position
            populateUnitSpinners()
            updateResult()
        }

        converterCard.addView(label("FROM", 11, muted, true).apply { setPadding(0, dp(16), 0, dp(6)) })
        input = EditText(this).apply {
            setSingleLine(true)
            textSize = 24f
            setTextColor(white)
            setHintTextColor(muted)
            hint = "Enter a quantity"
            inputType = android.text.InputType.TYPE_CLASS_NUMBER or
                android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL or
                android.text.InputType.TYPE_NUMBER_FLAG_SIGNED
            setPadding(dp(14), dp(13), dp(14), dp(13))
            background = rounded(panel2, 12)
        }
        converterCard.addView(input, matchWrap())
        fromSpinner = spinner(emptyList())
        converterCard.addView(fromSpinner, matchWrap(dp(8)))
        fromSpinner.onItemSelectedListener = simpleListener { updateResult() }

        val swapRow = LinearLayout(this).apply {
            gravity = Gravity.CENTER
            setPadding(0, dp(10), 0, dp(10))
        }
        val swap = actionButton("⇅  SWAP")
        swap.setOnClickListener {
            val a = fromSpinner.selectedItemPosition
            val b = toSpinner.selectedItemPosition
            fromSpinner.setSelection(b)
            toSpinner.setSelection(a)
            updateResult()
        }
        swapRow.addView(swap, LinearLayout.LayoutParams(-2, dp(42)))
        converterCard.addView(swapRow)

        converterCard.addView(label("TO", 11, muted, true))
        toSpinner = spinner(emptyList())
        converterCard.addView(toSpinner, matchWrap(dp(8)))
        toSpinner.onItemSelectedListener = simpleListener { updateResult() }

        val resultCard = card().apply { setPadding(dp(16), dp(17), dp(16), dp(17)) }
        val resultLabel = label("RESULT", 11, muted, true)
        resultCard.addView(resultLabel)
        resultText = label("0", 34, mint, true).apply { setPadding(0, dp(8), 0, 0) }
        resultCard.addView(resultText)
        resultUnit = label("", 13, muted, false).apply { setPadding(0, dp(3), 0, dp(12)) }
        resultCard.addView(resultUnit)
        val buttons = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val clear = actionButton("CLEAR")
        clear.setOnClickListener { input.setText(""); updateResult() }
        val save = actionButton("☆  FAVOURITE")
        save.setOnClickListener { saveFavourite() }
        buttons.addView(clear, LinearLayout.LayoutParams(0, dp(42), 1f).apply { marginEnd = dp(8) })
        buttons.addView(save, LinearLayout.LayoutParams(0, dp(42), 1f))
        resultCard.addView(buttons)
        root.addView(resultCard, matchWrap(dp(14)))

        input.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) { updateResult() }
            override fun afterTextChanged(s: Editable?) {}
        })

        root.addView(sectionTitle("FAVOURITES"))
        favouritesBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(favouritesBox, matchWrap())
        root.addView(sectionTitle("RECENT HISTORY"))
        historyBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(historyBox, matchWrap())
        root.addView(label("Sebedisana QV  •  Version 1.0", 11, muted, false).apply {
            gravity = Gravity.CENTER
            setPadding(0, dp(22), 0, 0)
        })
    }

    private fun populateUnitSpinners() {
        val names = categories[selectedCategory].units.map { "${it.name} (${it.symbol})" }
        updating = true
        fromSpinner.adapter = spinnerAdapter(names)
        toSpinner.adapter = spinnerAdapter(names)
        fromSpinner.setSelection(0)
        toSpinner.setSelection(if (names.size > 1) 1 else 0)
        updating = false
    }

    private fun updateResult() {
        if (!::resultText.isInitialized || !::fromSpinner.isInitialized || !::toSpinner.isInitialized) return
        if (updating) return
        val value = input.text.toString().trim().replace(',', '.').toDoubleOrNull()
        val units = categories[selectedCategory].units
        val from = units.getOrNull(fromSpinner.selectedItemPosition) ?: units.first()
        val to = units.getOrNull(toSpinner.selectedItemPosition) ?: units.first()
        if (value == null) {
            resultText.text = "—"
            resultUnit.text = "Enter a number to convert"
            return
        }
        val converted = convert(value, from, to, categories[selectedCategory].name)
        if (!converted.isFinite()) {
            resultText.text = "Invalid"
            resultUnit.text = "Please check the entered value"
        } else {
            resultText.text = fmt.format(converted)
            resultUnit.text = to.symbol
            addHistory()
        }
    }

    private fun convert(value: Double, from: UnitDef, to: UnitDef, category: String): Double {
        if (category == "Temperature") {
            val celsius = when (from.symbol) {
                "°C" -> value
                "°F" -> (value - 32.0) * 5.0 / 9.0
                "K" -> value - 273.15
                else -> value
            }
            return when (to.symbol) {
                "°C" -> celsius
                "°F" -> celsius * 9.0 / 5.0 + 32.0
                "K" -> celsius + 273.15
                else -> celsius
            }
        }
        return value * from.factor / to.factor
    }

    private fun saveFavourite() {
        val value = input.text.toString().trim()
        if (value.isEmpty()) {
            toast("Enter a quantity before saving a favourite")
            return
        }
        val from = fromSpinner.selectedItemPosition
        val to = toSpinner.selectedItemPosition
        val key = "$selectedCategory|$from|$to"
        val arr = readArray("favourites")
        for (i in 0 until arr.length()) if (arr.optString(i) == key) {
            toast("This favourite is already saved")
            return
        }
        arr.put(key)
        prefs.edit().putString("favourites", arr.toString()).apply()
        addHistory()
        refreshSavedLists()
        toast("Favourite saved")
    }

    private fun addHistory() {
        val value = input.text.toString().trim().replace(',', '.').toDoubleOrNull() ?: return
        val from = categories[selectedCategory].units[fromSpinner.selectedItemPosition]
        val to = categories[selectedCategory].units[toSpinner.selectedItemPosition]
        val result = convert(value, from, to, categories[selectedCategory].name)
        val entry = JSONObject().apply {
            put("category", selectedCategory); put("from", fromSpinner.selectedItemPosition)
            put("to", toSpinner.selectedItemPosition); put("value", value); put("result", result)
        }
        val old = readArray("history")
        val latest = old.optJSONObject(0)
        if (latest != null &&
            latest.optInt("category") == selectedCategory &&
            latest.optInt("from") == fromSpinner.selectedItemPosition &&
            latest.optInt("to") == toSpinner.selectedItemPosition &&
            latest.optDouble("value") == value) return
        val next = JSONArray().put(entry)
        for (i in 0 until minOf(old.length(), 19)) next.put(old.get(i))
        prefs.edit().putString("history", next.toString()).apply()
        refreshSavedLists()
    }

    private fun refreshSavedLists() {
        if (!::favouritesBox.isInitialized || !::historyBox.isInitialized) return
        favouritesBox.removeAllViews()
        val favs = readArray("favourites")
        if (favs.length() == 0) favouritesBox.addView(emptyNote("No favourites yet. Save a conversion using ☆ Favourite."))
        for (i in 0 until favs.length()) {
            val parts = favs.optString(i).split("|")
            if (parts.size != 3) continue
            val c = parts[0].toIntOrNull() ?: continue
            val f = parts[1].toIntOrNull() ?: continue
            val t = parts[2].toIntOrNull() ?: continue
            addSavedRow(favouritesBox, "${categories.getOrNull(c)?.name ?: "Conversion"} · ${unitName(c, f)} → ${unitName(c, t)}", {
                loadConversion(c, f, t)
            }, {
                val updated = JSONArray()
                for (j in 0 until favs.length()) if (j != i) updated.put(favs.get(j))
                prefs.edit().putString("favourites", updated.toString()).apply()
                refreshSavedLists()
            }, "✕")
        }

        historyBox.removeAllViews()
        val history = readArray("history")
        if (history.length() == 0) historyBox.addView(emptyNote("Your recent conversions will appear here."))
        for (i in 0 until history.length()) {
            val item = history.optJSONObject(i) ?: continue
            val c = item.optInt("category")
            val f = item.optInt("from")
            val t = item.optInt("to")
            val value = item.optDouble("value")
            val result = item.optDouble("result")
            val fromUnit = categories.getOrNull(c)?.units?.getOrNull(f) ?: continue
            val toUnit = categories[c].units.getOrNull(t) ?: continue
            addSavedRow(historyBox, "${fmt.format(value)} ${fromUnit.symbol} = ${fmt.format(result)} ${toUnit.symbol}", {
                loadConversion(c, f, t, value)
            }, {}, "↗")
        }
        if (history.length() > 0) {
            val clearHistory = TextView(this).apply {
                text = "CLEAR HISTORY"; textSize = 11f; setTextColor(mint)
                gravity = Gravity.END; setPadding(0, dp(8), 0, dp(8))
                setOnClickListener {
                    prefs.edit().remove("history").apply()
                    refreshSavedLists()
                }
            }
            historyBox.addView(clearHistory)
        }
    }

    private fun loadConversion(c: Int, f: Int, t: Int, value: Double? = null) {
        selectedCategory = c
        categorySpinner.setSelection(c)
        populateUnitSpinners()
        fromSpinner.setSelection(f)
        toSpinner.setSelection(t)
        if (value != null) input.setText(fmt.format(value))
        updateResult()
        input.requestFocus()
    }

    private fun unitName(c: Int, u: Int): String =
        categories.getOrNull(c)?.units?.getOrNull(u)?.symbol ?: "?"

    private fun addSavedRow(box: LinearLayout, title: String, onSelect: () -> Unit, onRemove: () -> Unit, removeText: String) {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            background = rounded(panel, 12); setPadding(dp(12), dp(11), dp(8), dp(11))
        }
        val text = TextView(this).apply {
            this.text = title; textSize = 13f; setTextColor(white)
            layoutParams = LinearLayout.LayoutParams(0, -2, 1f)
            setOnClickListener { onSelect() }
        }
        val open = TextView(this).apply {
            this.text = "OPEN"; textSize = 10f; setTextColor(mint); setPadding(dp(8), dp(8), dp(8), dp(8))
            setOnClickListener { onSelect() }
        }
        val remove = TextView(this).apply {
            text = removeText; textSize = 16f; setTextColor(muted); setPadding(dp(10), dp(6), dp(6), dp(6))
            setOnClickListener { onRemove() }
        }
        row.addView(text); row.addView(open); row.addView(remove)
        box.addView(row, matchWrap(dp(7)))
    }

    private fun readArray(key: String): JSONArray = try {
        JSONArray(prefs.getString(key, "[]") ?: "[]")
    } catch (_: Exception) { JSONArray() }

    private fun spinner(items: List<String>): Spinner = Spinner(this).apply {
        adapter = spinnerAdapter(items)
        background = rounded(panel2, 10)
        setPadding(dp(8), dp(3), dp(8), dp(3))
    }

    private fun spinnerAdapter(items: List<String>) = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, items).also {
        it.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
    }

    private fun simpleListener(action: (Int) -> Unit) = object : AdapterView.OnItemSelectedListener {
        override fun onNothingSelected(parent: AdapterView<*>?) {}
        override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) { action(position) }
    }

    private fun card() = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(16), dp(16), dp(16), dp(16))
        background = rounded(panel, 18)
    }

    private fun sectionTitle(text: String) = label(text, 12, white, true).apply {
        setPadding(0, dp(22), 0, dp(10))
    }

    private fun emptyNote(text: String) = label(text, 12, muted, false).apply {
        setPadding(dp(4), dp(8), dp(4), dp(8))
    }

    private fun label(text: String, size: Int, color: Int, bold: Boolean) = TextView(this).apply {
        this.text = text; textSize = size.toFloat(); setTextColor(color)
        if (bold) setTypeface(typeface, Typeface.BOLD)
    }

    private fun actionButton(text: String) = TextView(this).apply {
        this.text = text; textSize = 12f; gravity = Gravity.CENTER
        setTextColor(mint); setTypeface(typeface, Typeface.BOLD)
        background = rounded(panel2, 12); setPadding(dp(12), 0, dp(12), 0)
    }

    private fun rounded(color: Int, radius: Int) = GradientDrawable().apply {
        setColor(color); cornerRadius = dp(radius).toFloat()
    }

    private fun matchWrap(top: Int = 0) = LinearLayout.LayoutParams(
        ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
    ).apply { if (top > 0) topMargin = dp(top) }

    private fun dp(value: Int) = (value * resources.displayMetrics.density).toInt()
    private fun toast(message: String) = Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
}
