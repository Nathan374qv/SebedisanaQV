# Privacy Policy — Sebedisana QV

**Effective date:** [insert publication date]

Sebedisana QV is a unit conversion app. This policy describes the information handled by the app.

## Information processed on your device
Values entered for conversion, favourite conversion settings and recent conversion history are processed and stored locally on your device using Android app storage. The app does not send these values to the developer or to a server.

## Data sharing and advertising
The current app build does not include advertising SDKs, analytics SDKs, account registration or network-based services. No information is shared with third parties by the app.

## Data deletion
You can clear recent history in the app. Uninstalling the app removes its locally stored app data. Favourites can be removed individually in the app.

## Children
The app is a general-purpose utility and does not knowingly collect personal information from children.

## Changes and contact
If the app's features or data practices change, this policy will be updated. For privacy questions, contact: [insert a monitored contact email].
